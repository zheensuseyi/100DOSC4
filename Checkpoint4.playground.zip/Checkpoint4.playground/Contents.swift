// Zheen H. Suseyi
// 09/23/24
/*
 The challenge is this: write a function that accepts an integer from 1 through 10,000, and returns the integer square root of that number. That sounds easy, but there are some catches:

 You can’t use Swift’s built-in sqrt() function or similar – you need to find the square root yourself.
 If the number is less than 1 or greater than 10,000 you should throw an “out of bounds” error.
 You should only consider integer square roots – don’t worry about the square root of 3 being 1.732, for example.
 If you can’t find the square root, throw a “no root” error.
 As a reminder, if you have number X, the square root of X will be another number that, when multiplied by itself, gives X. So, the square root of 9 is 3, because 3x3 is 9, and the square root of 25 is 5, because 5x5 is 25.
 */


import UIKit

// setting up our function errors with their cases
enum functionErrors: Error {
    case outofbounds, noroot
}

// Function to find the square root of a number that will only find perfect squares
func sqrtInt(number: Double, precision: Double = 0.001) throws -> Double {
    // if number is out of bounds, then throw the outofbounds error
    if number > 10_000 || number < 1  {
        print("This number is out of bounds!")
        throw functionErrors.outofbounds
    }
    
    // formula to test if a number is a perfect square
    var guess = number / 2.0
    while abs(guess * guess - number) > precision {
        guess = (guess + number / guess) / 2.0
    }
    
    // This is to make sure numbers like 3 which have a decimal square root are not counted since we are only looking for perfect squares
    let roundedGuess = round(guess)
    if roundedGuess * roundedGuess != number {
        print("The number does not have an integer square root!")
        throw functionErrors.noroot
    }
    
    // Returning our perfect square
    return roundedGuess
}

// Testing out our function
do {
    var luckyGuess = try sqrtInt(number: 3)
    print("And the square root of your number is \(luckyGuess) !")
}

// if out of bounds
catch functionErrors.outofbounds {
    print("This number is out of bounds! Try entering a number between 1-10000")
}

// if no perfect square
catch functionErrors.noroot {
    print("It appears that this number doesn't have a perfect integer square root")
}

// if some unknown error
catch {
    print("Not sure what happened here! Try again")
}

